print(
    "hello may dua"
)